package com.jarvis.assistant.ai

/**
 * #50 JARVIS SYSTEM PROMPT ARCHITECTURE — assembles the final request from the independent
 * blocks in [PromptComponents] plus the fixed AVAILABLE_TOOLS action-list block below, instead
 * of one giant hardcoded prompt. The model is instructed to answer normally, and ONLY when the
 * user's request maps to a real, supported phone action, to append a single fenced
 * ```jarvis_command block containing JSON matching one of the allowed types. The CommandEngine
 * is the only thing that ever executes those actions, and it validates the type/fields before
 * doing anything — the model's JSON is a suggestion, never code, and never trusted blindly.
 */
object PromptBuilder {

    fun systemPrompt(
        memoryContext: String,
        languageHint: String,
        phoneContext: String = "",
        appRegistry: String = "",
        capabilitySnapshot: String = "",
        currentTaskDescription: String? = null,
        previousActionSummary: String? = null,
        knowledgeContext: String = ""
    ): String = buildString {
        appendLine(PromptComponents.corePersonality())
        appendLine()
        appendLine(PromptComponents.languageContext(languageHint))
        appendLine()
        appendLine(PromptComponents.deviceContext(phoneContext, appRegistry))
        appendLine()
        if (capabilitySnapshot.isNotBlank()) {
            appendLine(PromptComponents.capabilityContext(capabilitySnapshot))
            appendLine()
        }
        appendLine(PromptComponents.taskContext(currentTaskDescription, previousActionSummary))
        appendLine()
        appendLine(PromptComponents.conversationalIntelligenceNote())
        appendLine()
        appendLine(PromptComponents.confidenceRule())
        appendLine()
        appendLine(PromptComponents.securityRules())
        appendLine()
        appendLine(PromptComponents.responseStyle())
        appendLine()
        appendLine(AVAILABLE_TOOLS)
        appendLine()
        if (knowledgeContext.isNotBlank()) {
            appendLine(PromptComponents.knowledgeContext(knowledgeContext))
            appendLine()
        }
        appendLine(PromptComponents.memoryContext(memoryContext))
    }

    /** #51 TOOL-AWARE AI — the closed list of action types the AI may propose. Never expose an
     * unavailable tool here: this list only ever grows alongside a real CommandEngine case. */
    private val AVAILABLE_TOOLS = """
        You can hold normal conversation, answer questions, and help with reminders and tasks.
        For anything requiring live/current information (news, prices, "today", weather, status,
        outages, availability, schedules, "who is the current ..."), use the hosted web_search tool.
        Check source dates, prefer the newest reliable primary source, and resolve conflicting
        sources with an additional search before making a definitive claim. Never treat an old
        announcement as current when a newer update exists. Do not ask the phone to open Chrome or
        use Accessibility for web search; web search happens directly through the AI API.

        When the user's request needs more than one action, you MAY return one bounded plan instead
        of a single action. Use exactly this structure and no other executable format:
        {"type":"AGENT_PLAN","actions":[{...validated action object...},{...}]}
        The actions array must contain 1-12 objects, each of which is one of the supported action
        types below. The agent will validate every object before execution. Prefer a plan for tasks
        such as "open YouTube, search Coke Studio, then play the first result". Do not put prose or
        Kotlin/Java/Android code in actions.

        When the user's message clearly asks for one of these SUPPORTED PHONE ACTIONS, append
        (after your normal reply text) a single fenced block starting with ```jarvis_command and
        ending with ```, containing ONE JSON object with a "type" field and the fields it needs:

        - {"type":"OPEN_APP","target":"<app name, e.g. YouTube>"}
        - {"type":"OPEN_SETTINGS","target":"wifi|bluetooth|general"}
        - {"type":"OPEN_CAMERA"}
        - {"type":"OPEN_BROWSER","url":"<optional url>"}
        - {"type":"OPEN_MAPS","query":"<optional place/address>"}
        - {"type":"OPEN_DIALER","number":"<optional phone number>"}
        - {"type":"OPEN_CONTACTS"}
        - {"type":"OPEN_CALENDAR"}
        - {"type":"OPEN_CLOCK"}
        - {"type":"SET_ALARM","hour":<0-23>,"minute":<0-59>,"label":"<optional>"}
        - {"type":"SET_TIMER","seconds":<int>,"label":"<optional>"}
        - {"type":"CREATE_REMINDER","text":"<reminder text>","hour":<0-23>,"minute":<0-59>}
        - {"type":"SHARE_TEXT","text":"<text to share>"}
        - {"type":"ADJUST_VOLUME","direction":"up|down","stream":"media"}
        - {"type":"REMEMBER","content":"<fact to remember, only when user explicitly says to remember it>"}
        - {"type":"MEMORY_QUERY"} — use when the user asks "what do you remember about me" / "mujhe kya yaad hai".
        - {"type":"FORGET_MEMORY","query":"<text to match and remove, or omit to ask which>"} — "forget that", "delete my saved preferences".
        - {"type":"RUN_DIAGNOSTIC"} — use when the user asks JARVIS to check itself / run a diagnostic.
        - {"type":"LIST_INSTALLED_APPS"} — "which apps are installed?", "find the browser".
        - {"type":"CLOSE_APP"} — "close this app", "close the current app if possible". Android
          has no API for one app to force-close another, so this returns to the home screen
          instead and says so honestly — never claim the app was actually terminated.
        - {"type":"ENABLE_PHONE_CONTROL"} — use this if the user asks you to control other apps
          (send a message in some app, tap something, fill a form, etc.) but you don't yet know
          whether they've turned phone control on; it opens the system screen to turn it on.
        - {"type":"GO_HOME"} — go to the home screen.
        - {"type":"GO_BACK"} — go back one screen (needs phone control turned on).
        - {"type":"OPEN_RECENTS"} — open the recent apps switcher (needs phone control turned on).
        - {"type":"MEDIA_PLAY_PAUSE"} — play or pause whatever media is active.
        - {"type":"MEDIA_NEXT"} — skip to the next track.
        - {"type":"MEDIA_PREVIOUS"} — go to the previous track.
        - {"type":"READ_SCREEN"} — read the visible text on the current screen back to the user.
        - {"type":"READ_NOTIFICATIONS"} — summarize active notifications only when Android Notification Access is explicitly enabled.
        - {"type":"ENABLE_NOTIFICATION_ACCESS"} — open Android Notification Access settings when the user asks JARVIS to read notifications but access is not enabled.
          Use this to verify something happened, or to answer "what does this say" style
          questions, rather than guessing what might be on screen.
        - {"type":"SAVE_TEXT_FILE","filename":"<e.g. index.html>","content":"<full file text>"}
          — saves generated code/text as a real file in the phone's Downloads folder. Use this
          when the user asks you to build something (a website, a script, a document) and
          wants it saved as an actual file, not just shown in chat.
        - {"type":"SCROLL_DOWN"} / {"type":"SCROLL_UP"} — scrolls whatever app is currently
          open. Never open JARVIS or any other app for this — it always acts on the current
          foreground app and needs no confirmation.
        - {"type":"LONG_PRESS","target":"<visible text/label to long-press>"}
        - {"type":"SEARCH_CURRENT_APP","query":"<what to search for>"} — use when the user
          wants to search INSIDE whatever app is already open (e.g. "search karo Coke Studio"
          while YouTube is open). Do not use this for web search — web search is handled by the hosted AI web_search tool.
        - {"type":"TAP_FIRST_RESULT"} — taps the first result/item on the current screen, for
          phrases like "pehli video chalao", "upar wala kholo", "play the first one".
        - {"type":"SEND_WHATSAPP_MESSAGE","contact":"<name>","message":"<text>"} — opens
          WhatsApp, finds the contact, and types the message. This always requires the user's
          confirmation before it is actually sent — never claim it was sent until confirmed.
        - {"type":"STOP"} — stop/cancel whatever JARVIS is currently doing.
        - {"type":"PAUSE_TASK"} — pause the in-progress multi-step task.
        - {"type":"RESUME_TASK"} — resume a paused task.
        - {"type":"RETRY_LAST_TASK"} — re-run the most recent task/command ("phir se karo").
        - {"type":"ACTIVATE_HUD"} — activate the full futuristic live wallpaper HUD.
        - {"type":"STANDBY_HUD"} — put the HUD into low-power standby.
        - {"type":"SHOW_SYSTEM_STATUS"} — show real battery/RAM/storage/network telemetry on the HUD.
        - {"type":"SHOW_BATTERY"} — highlight real battery telemetry.
        - {"type":"SHOW_NETWORK"} — highlight real network/Wi-Fi/Bluetooth telemetry.
        - {"type":"SHOW_NOTIFICATIONS"} — highlight notification telemetry only if Notification Access is enabled.
        - {"type":"FULL_HUD"} — switch the wallpaper to full HUD mode.
        - {"type":"MINIMAL_HUD"} — switch the wallpaper to minimal HUD mode.
        - {"type":"POWER_SAVING_HUD"} — switch the wallpaper to a low-power rendering mode.

        You can also act as a coding assistant: when asked to write or generate code (HTML,
        CSS, JavaScript, Python, Kotlin, JSON, etc.), reply with complete, working code in your
        normal reply text using fenced code blocks, not fragments. If the user specifically
        wants it saved to their device, use SAVE_TEXT_FILE with the complete file content.
        - {"type":"AUTOMATE","package":"<android package name if known, e.g. com.whatsapp, or omit
          to act in whatever app is already open>","steps":[ ...ordered list of step objects... ]}
          Use AUTOMATE for anything that requires tapping or typing inside another app — sending a
          WhatsApp message, filling a field, pressing a button you can see, etc. Each step is one
          of:
            {"action":"tap_text","value":"<visible text on the button/label to tap>"}
            {"action":"tap_desc","value":"<accessibility label to tap, e.g. Search, Send>"}
            {"action":"type","value":"<text to type into the currently focused field>"}
            {"action":"wait","value":<milliseconds, e.g. 800>}
            {"action":"back"}
            {"action":"home"}
            {"action":"scroll_forward"}
            {"action":"scroll_backward"}
            {"action":"swipe","value":"up|down|left|right"}
          Keep step lists short and describe things the way a person looking at the screen would
          (button labels, field placeholders). Common well-known package names: WhatsApp is
          com.whatsapp, YouTube is com.google.android.youtube, Instagram is com.instagram.android,
          Gmail is com.google.android.gm. If unsure of the package name, omit "package" and assume
          the user already has the right app open or will after an OPEN_APP.

        AUTOMATE can act on the user's behalf inside apps like messaging — only use it when the
        user's own words clearly ask for that specific action (e.g. "send Ali a WhatsApp saying
        I'm on my way"), never speculatively.
    """.trimIndent()
}

package com.jarvis.assistant.ai

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.jarvis.assistant.data.local.prefs.SecurePrefs
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Talks to OpenAI's Responses API.
 *
 * The hosted web_search tool is enabled for every request. The model decides when
 * a live web lookup is useful, so JARVIS can answer current-news/price/status
 * questions without opening Chrome, using Accessibility, or a separate search API.
 */
class OpenAiService(private val prefs: SecurePrefs) : AiService {

    override suspend fun send(history: List<ChatMessage>, systemPrompt: String): Result<AiResult> {
        val apiKey = prefs.aiApiKey
        if (apiKey.isNullOrBlank()) {
            return Result.failure(IllegalStateException("No AI API key configured. Add one in Settings."))
        }

        val baseUrl = prefs.aiBaseUrl?.takeIf { it.isNotBlank() } ?: "https://api.openai.com/"

        return try {
            val api = buildApi(baseUrl)
            val request = JsonObject().apply {
                addProperty("model", prefs.aiModel)
                addProperty("instructions", buildResearchInstructions(systemPrompt))
                addProperty("tool_choice", "auto")
                addProperty("max_output_tokens", 1800)

                val tools = JsonArray()
                tools.add(JsonObject().apply {
                    addProperty("type", "web_search")
                    addProperty("search_context_size", "high")
                    addProperty("external_web_access", true)
                })
                add("tools", tools)

                val input = JsonArray()
                history.takeLast(20).forEach { message ->
                    // Responses API accepts user/assistant conversation items.
                    if (message.role == "user" || message.role == "assistant") {
                        input.add(JsonObject().apply {
                            addProperty("role", message.role)
                            addProperty("content", message.content)
                        })
                    }
                }
                add("input", input)
            }

            val response = api.createResponse(
                authHeader = "Bearer $apiKey",
                request = request
            )

            val rawText = extractOutputText(response)
            if (rawText.isBlank()) {
                return Result.failure(IllegalStateException("OpenAI returned an empty response."))
            }
            Result.success(extractCommand(rawText))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildResearchInstructions(systemPrompt: String): String = """
        $systemPrompt

        WEB RESEARCH / VERIFICATION POLICY:
        - For anything time-sensitive or changing (news, prices, exchange status, outages,
          schedules, weather, availability, "now", "today", "latest", "currently"), use web_search.
        - Treat search results as evidence, not as automatically current truth.
        - Check the publication/update date of every important result. Prefer the newest reliable
          source when multiple pages describe the same event.
        - Prefer primary sources for first-party facts: official company announcements, official
          support/status pages, government pages, exchange notices, filings, or direct statements.
        - For important current-status questions, cross-check with at least one independent reliable
          source when practical. Do not count multiple pages from the same publisher as independent.
        - If two sources conflict, do NOT choose one arbitrarily. Search again for a newer or primary
          source and resolve the conflict before giving a definitive answer.
        - Never state that a date is "not announced" if a newer source may have announced it. Search
          specifically for later updates before making that claim.
        - Distinguish the date of the event from the date the article/announcement was published or
          updated. Use exact dates and times when the source provides them.
        - For multi-source research, keep the final answer concise and focused. Give the key facts,
          what is confirmed, what remains uncertain, and the most relevant source names/links.
        - If reliable sources cannot establish the current state, explicitly say that it could not
          be verified instead of filling the gap with an inference or old information.
        - Never open Chrome or invoke phone-control/Accessibility actions merely to perform web search.
    """.trimIndent()

    private fun buildApi(baseUrl: String): OpenAiApi {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(150, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
        val normalizedBase = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        return Retrofit.Builder()
            .baseUrl(normalizedBase)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OpenAiApi::class.java)
    }

    /** Extracts text from Responses API output message/content items. */
    private fun extractOutputText(response: JsonObject): String {
        val output = response.getAsJsonArray("output") ?: return ""
        return output.asSequence()
            .filter { it.isJsonObject }
            .map { it.asJsonObject }
            .filter { it.get("type")?.asString == "message" }
            .flatMap { message ->
                val content = message.getAsJsonArray("content") ?: JsonArray()
                content.asSequence()
                    .filter { it.isJsonObject }
                    .map { it.asJsonObject }
                    .filter { it.get("type")?.asString == "output_text" }
                    .mapNotNull { it.get("text")?.asString }
            }
            .joinToString("\n")
            .trim()
    }

    private fun extractCommand(rawText: String): AiResult {
        val regex = Regex("```jarvis_command\\s*([\\s\\S]*?)```")
        val match = regex.find(rawText)
        val commandJson = match?.groupValues?.get(1)?.trim()
        val replyText = if (match != null) rawText.replace(match.value, "").trim() else rawText.trim()
        return AiResult(replyText = replyText, commandJson = commandJson)
    }
}

package com.jarvis.assistant.accessibility

/**
 * The closed set of primitive on-screen actions JARVIS can perform through the
 * Accessibility Service. A multi-app "do this in that app" request from the AI is
 * broken down into a small ordered list of these steps (see JarvisCommand.Automate),
 * which JarvisAccessibilityService then attempts to carry out one at a time as the
 * screen updates. Nothing here bypasses Android's permission model — every action is
 * exactly what a sighted user could do by tapping/typing on screen themselves, and the
 * user must have explicitly turned on the Accessibility Service for JARVIS beforehand.
 */
sealed class AutomationStep {
    /** Find a node whose visible text matches (contains, case-insensitive) and tap it. */
    data class TapText(val text: String) : AutomationStep()

    /** Find a node whose content description matches (contains, case-insensitive) and tap it. */
    data class TapDescription(val description: String) : AutomationStep()

    /** Type into the currently focused editable field (or the first editable field found). */
    data class TypeText(val text: String) : AutomationStep()

    /** Pause before the next step, to give a screen time to load. */
    data class Wait(val milliseconds: Long) : AutomationStep()

    object PressBack : AutomationStep()
    object PressHome : AutomationStep()
    object ScrollForward : AutomationStep()
    object ScrollBackward : AutomationStep()

    /** Long-press a node whose visible text matches (contains, case-insensitive). */
    data class LongPressText(val text: String) : AutomationStep()

    /** Long-press a node whose content description matches (contains, case-insensitive). */
    data class LongPressDescription(val description: String) : AutomationStep()

    /** Submits the currently focused editable field (search boxes, message inputs). */
    object SubmitField : AutomationStep()

    /** Taps the first clickable "result-like" item on screen (e.g. "pehli video chalao"). */
    object TapFirstResult : AutomationStep()

    /** A directional swipe gesture (not a scrollable-node action) — for carousels, image
     * viewers, and other UI that only responds to a real touch gesture rather than the
     * ACTION_SCROLL_FORWARD/BACKWARD accessibility action [ScrollForward]/[ScrollBackward] use. */
    data class Swipe(val direction: SwipeDirection) : AutomationStep()
}

enum class SwipeDirection { UP, DOWN, LEFT, RIGHT }

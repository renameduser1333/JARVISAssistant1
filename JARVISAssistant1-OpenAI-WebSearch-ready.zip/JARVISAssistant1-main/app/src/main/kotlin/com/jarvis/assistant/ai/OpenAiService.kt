package com.jarvis.assistant.ai

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.jarvis.assistant.data.local.prefs.SecurePrefs
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Talks to OpenAI's Responses API.
 *
 * The hosted web_search tool is enabled for every request. The model decides when
 * a live web lookup is useful, so JARVIS can answer current-news/price/status
 * questions without opening Chrome, using Accessibility, or a separate search API.
 */
class OpenAiService(private val prefs: SecurePrefs) : AiService {

    override suspend fun send(history: List<ChatMessage>, systemPrompt: String): Result<AiResult> {
        val apiKey = prefs.aiApiKey
        if (apiKey.isNullOrBlank()) {
            return Result.failure(IllegalStateException("No AI API key configured. Add one in Settings."))
        }

        val baseUrl = prefs.aiBaseUrl?.takeIf { it.isNotBlank() } ?: "https://api.openai.com/"

        return try {
            val api = buildApi(baseUrl)
            val request = JsonObject().apply {
                addProperty("model", prefs.aiModel)
                addProperty("instructions", systemPrompt)
                addProperty("tool_choice", "auto")
                addProperty("max_output_tokens", 1200)

                val tools = JsonArray()
                tools.add(JsonObject().apply {
                    addProperty("type", "web_search")
                    addProperty("search_context_size", "medium")
                    addProperty("external_web_access", true)
                })
                add("tools", tools)

                val input = JsonArray()
                history.takeLast(20).forEach { message ->
                    // Responses API accepts user/assistant conversation items.
                    if (message.role == "user" || message.role == "assistant") {
                        input.add(JsonObject().apply {
                            addProperty("role", message.role)
                            addProperty("content", message.content)
                        })
                    }
                }
                add("input", input)
            }

            val response = api.createResponse(
                authHeader = "Bearer $apiKey",
                request = request
            )

            val rawText = extractOutputText(response)
            if (rawText.isBlank()) {
                return Result.failure(IllegalStateException("OpenAI returned an empty response."))
            }
            Result.success(extractCommand(rawText))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildApi(baseUrl: String): OpenAiApi {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
        val normalizedBase = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        return Retrofit.Builder()
            .baseUrl(normalizedBase)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OpenAiApi::class.java)
    }

    /** Extracts text from Responses API output message/content items. */
    private fun extractOutputText(response: JsonObject): String {
        val output = response.getAsJsonArray("output") ?: return ""
        return output.asSequence()
            .filter { it.isJsonObject }
            .map { it.asJsonObject }
            .filter { it.get("type")?.asString == "message" }
            .flatMap { message ->
                val content = message.getAsJsonArray("content") ?: JsonArray()
                content.asSequence()
                    .filter { it.isJsonObject }
                    .map { it.asJsonObject }
                    .filter { it.get("type")?.asString == "output_text" }
                    .mapNotNull { it.get("text")?.asString }
            }
            .joinToString("\n")
            .trim()
    }

    private fun extractCommand(rawText: String): AiResult {
        val regex = Regex("```jarvis_command\\s*([\\s\\S]*?)```")
        val match = regex.find(rawText)
        val commandJson = match?.groupValues?.get(1)?.trim()
        val replyText = if (match != null) rawText.replace(match.value, "").trim() else rawText.trim()
        return AiResult(replyText = replyText, commandJson = commandJson)
    }
}

package com.jarvis.assistant.ui.screens.home

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.hud.DeviceTelemetryRepository
import com.jarvis.assistant.hud.HudCommandExecutor
import com.jarvis.assistant.hud.JarvisHudState
import com.jarvis.assistant.hud.WallpaperEventBus
import com.jarvis.assistant.ui.AssistantViewModel
import com.jarvis.assistant.voice.VoiceState
import com.jarvis.assistant.ui.theme.JarvisCyan
import com.jarvis.assistant.ui.theme.JarvisError
import com.jarvis.assistant.ui.theme.JarvisSuccess
import com.jarvis.assistant.ui.theme.JarvisTextSecondary
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.foundation.shape.CircleShape

@Composable
fun HomeScreen(
    viewModel: AssistantViewModel,
    onOpenDashboard: () -> Unit = {},
    onOpenPermissions: () -> Unit = {},
    onOpenMemory: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    onOpenRemote: () -> Unit = {},
    onOpenWinGo: () -> Unit = {},
    onOpenQuotex: () -> Unit = {}
) {
    val voice by viewModel.voiceState.collectAsState()
    val status by viewModel.statusText.collectAsState()
    val response by viewModel.lastResponse.collectAsState()
    val pending by viewModel.pendingCommand.collectAsState()
    val plan by viewModel.pendingPlan.collectAsState()
    val hud by WallpaperEventBus.state.collectAsState()
    val telemetryRepo = remember { DeviceTelemetryRepository(viewModel.getApplication()) }
    val telemetry by telemetryRepo.telemetry.collectAsState()
    val scope = rememberCoroutineScope()
    DisposableEffect(telemetryRepo) {
        telemetryRepo.start(scope, 2000L)
        onDispose { telemetryRepo.stop() }
    }

    // #25 NOTIFICATIONS — a real, debounced low-battery warning (fires once per drop below the
    // threshold, not once per telemetry tick).
    androidx.compose.runtime.LaunchedEffect(telemetry.batteryPercent, telemetry.charging) {
        com.jarvis.assistant.agent.JarvisNotifier.maybeNotifyLowBattery(
            viewModel.getApplication(),
            viewModel.securePrefsForNotifications(),
            telemetry.batteryPercent,
            telemetry.charging == true
        )
    }

    val voiceState = when (voice) {
        VoiceState.LISTENING -> JarvisHudState.LISTENING
        VoiceState.THINKING -> JarvisHudState.THINKING
        VoiceState.SPEAKING -> JarvisHudState.COMPLETED
        VoiceState.ERROR -> JarvisHudState.ERROR
        VoiceState.IDLE -> hud.state
    }

    Box(
        Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0xFF02070D))
    ) {
        HudBackground()
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("JARVIS", color = JarvisCyan, fontSize = 28.sp, fontFamily = FontFamily.Monospace)
                    Text("PERSONAL AI CONTROL SYSTEM", color = JarvisTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Text(
                    text = "● ${voiceState.name}",
                    color = if (voiceState == JarvisHudState.ERROR) JarvisError else JarvisCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(Modifier.height(12.dp))
            TelemetryStrip(telemetry)

            Spacer(Modifier.height(8.dp))
            var radialMenuOpen by remember { mutableStateOf(false) }
            Box(modifier = Modifier.size(320.dp), contentAlignment = Alignment.Center) {
                JarvisCore(
                    state = voiceState,
                    modifier = Modifier.size(260.dp).pointerInput(voice) {
                        detectTapGestures(
                            onTap = {
                                if (voice == VoiceState.LISTENING) viewModel.cancelListening()
                                else viewModel.startListening(null)
                            },
                            onLongPress = { radialMenuOpen = true }
                        )
                    }
                )
                // #20 UI ARCHITECTURE — a HUD-style radial quick-access menu, additive to (not
                // replacing) the bottom nav: long-press the core to reveal it.
                RadialQuickMenu(
                    visible = radialMenuOpen,
                    onDismiss = { radialMenuOpen = false },
                    items = listOf(
                        RadialMenuItem("DIAG") { viewModel.sendMessage("run jarvis diagnostic", true) },
                        RadialMenuItem("DASH", onOpenDashboard),
                        RadialMenuItem("PERM", onOpenPermissions),
                        RadialMenuItem("MEM", onOpenMemory),
                        RadialMenuItem("CTRL", onOpenRemote),
                        RadialMenuItem("WIN", onOpenWinGo),
                        RadialMenuItem("QTX", onOpenQuotex)
                    )
                )
            }

            Text(status.uppercase(), color = JarvisCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            if (response.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = androidx.compose.ui.graphics.Color(0xCC06131C),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(response, color = JarvisCyan, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(12.dp))
                }
            }

            Spacer(Modifier.height(10.dp))
            QuickCommandGrid(viewModel)
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                HudChip("PHONE CONTROL", JarvisAccessibilityService.isEnabled)
                HudChip("HUD", true)
                HudChip("AI", true)
            }
        }
    }

    pending?.let {
        AlertDialog(
            onDismissRequest = { viewModel.confirmPendingCommand(false) },
            title = { Text("JARVIS CONFIRMATION") },
            text = { Text(it.confirmationText) },
            confirmButton = { TextButton(onClick = { viewModel.confirmPendingCommand(true) }) { Text("EXECUTE") } },
            dismissButton = { TextButton(onClick = { viewModel.confirmPendingCommand(false) }) { Text("CANCEL") } }
        )
    }
    plan?.let {
        AlertDialog(
            onDismissRequest = { viewModel.confirmPendingPlan(false) },
            title = { Text("MULTI-STEP COMMAND") },
            text = { Text(it.confirmationText) },
            confirmButton = { TextButton(onClick = { viewModel.confirmPendingPlan(true) }) { Text("EXECUTE") } },
            dismissButton = { TextButton(onClick = { viewModel.confirmPendingPlan(false) }) { Text("CANCEL") } }
        )
    }
}

@Composable
private fun JarvisCore(state: JarvisHudState, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "jarvis-core")
    val angle by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (state == JarvisHudState.LISTENING) 1100 else 2600, easing = LinearEasing), RepeatMode.Restart),
        label = "rotation"
    )
    Canvas(modifier) {
        val c = center
        val r = size.minDimension * .38f
        drawCircle(JarvisCyan.copy(alpha = .05f), r * 1.8f)
        drawCircle(JarvisCyan.copy(alpha = .16f), r * 1.25f, style = Stroke(2f))
        val tickR = r * 1.28f
        for (i in 0 until 60) {
            val major = i % 5 == 0
            val a = Math.toRadians((i * 6.0) + angle)
            val len = if (major) tickR * .07f else tickR * .035f
            val cosA = kotlin.math.cos(a).toFloat()
            val sinA = kotlin.math.sin(a).toFloat()
            drawLine(
                JarvisCyan.copy(alpha = if (major) .55f else .28f),
                androidx.compose.ui.geometry.Offset(c.x + cosA * tickR, c.y + sinA * tickR),
                androidx.compose.ui.geometry.Offset(c.x + cosA * (tickR - len), c.y + sinA * (tickR - len)),
                if (major) 2f else 1f
            )
        }
        for (i in 0..3) {
            val rr = r * (0.65f + i * .22f)
            drawArc(JarvisCyan.copy(alpha = .7f - i * .1f), angle * if (i % 2 == 0) 1 else -1, 260f, false, style = Stroke(if (i == 1) 3f else 1.5f, cap = StrokeCap.Round), topLeft = androidx.compose.ui.geometry.Offset(c.x - rr, c.y - rr), size = androidx.compose.ui.geometry.Size(rr * 2, rr * 2))
        }
        val pulse = if (state == JarvisHudState.ERROR) .25f else .12f
        drawCircle(JarvisCyan.copy(alpha = pulse), r * .55f)
        drawCircle(JarvisCyan, r * .24f)
        drawCircle(androidx.compose.ui.graphics.Color.White, r * .08f)
    }
}

@Composable
private fun HudBackground() {
    Canvas(Modifier.fillMaxSize()) {
        val step = size.minDimension / 12f
        for (x in 0..12) drawLine(JarvisCyan.copy(alpha = .035f), androidx.compose.ui.geometry.Offset(x * step, 0f), androidx.compose.ui.geometry.Offset(x * step, size.height))
        for (y in 0..24) drawLine(JarvisCyan.copy(alpha = .025f), androidx.compose.ui.geometry.Offset(0f, y * step), androidx.compose.ui.geometry.Offset(size.width, y * step))
        val l = 28f
        val s = 1.5f
        drawLine(JarvisCyan.copy(alpha=.45f), androidx.compose.ui.geometry.Offset(10f,10f), androidx.compose.ui.geometry.Offset(10f+l,10f), s)
        drawLine(JarvisCyan.copy(alpha=.45f), androidx.compose.ui.geometry.Offset(10f,10f), androidx.compose.ui.geometry.Offset(10f,10f+l), s)
        drawLine(JarvisCyan.copy(alpha=.45f), androidx.compose.ui.geometry.Offset(size.width-10f,10f), androidx.compose.ui.geometry.Offset(size.width-10f-l,10f), s)
        drawLine(JarvisCyan.copy(alpha=.45f), androidx.compose.ui.geometry.Offset(size.width-10f,10f), androidx.compose.ui.geometry.Offset(size.width-10f,10f+l), s)
    }
}

@Composable
private fun TelemetryStrip(t: com.jarvis.assistant.hud.DeviceTelemetry) {
    val ramPct = if (t.ramUsedGb != null && t.ramTotalGb != null && t.ramTotalGb!! > 0f) t.ramUsedGb!! / t.ramTotalGb!! else null
    val storagePct = if (t.storageUsedGb != null && t.storageTotalGb != null && t.storageTotalGb!! > 0f) t.storageUsedGb!! / t.storageTotalGb!! else null
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RingGauge("BATTERY", t.batteryPercent?.let { "$it%" } ?: "—", t.batteryPercent?.let { it / 100f })
            RingGauge("RAM", ramPct?.let { "${(it * 100).toInt()}%" } ?: "—", ramPct)
            RingGauge("DISK", storagePct?.let { "${(it * 100).toInt()}%" } ?: "—", storagePct)
            RingGauge("WIFI", when (t.wifiConnected) { true -> "ON"; false -> "OFF"; null -> "—" }, if (t.wifiConnected == true) 1f else 0f)
        }
        // #9 DEVICE UNDERSTANDING — CPU core count. No live-load ring here: modern Android has
        // no public API for real-time CPU load, so this stays an honest static fact rather
        // than a fake-looking gauge with nothing real driving it.
        t.cpuCoreCount?.let { cores ->
            Text(
                "CPU: $cores CORES",
                color = JarvisTextSecondary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

/** Small circular donut meter — the ring-gauge look from the reference HUD skin. */
@Composable
private fun RingGauge(label: String, valueText: String, percent: Float?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(56.dp)) {
                val stroke = Stroke(size.minDimension * .14f, cap = StrokeCap.Round)
                drawArc(JarvisCyan.copy(alpha = .18f), 0f, 360f, false, style = stroke)
                if (percent != null) {
                    drawArc(JarvisCyan, -90f, percent.coerceIn(0f, 1f) * 360f, false, style = stroke)
                }
            }
            Text(valueText, color = JarvisCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = JarvisTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun QuickCommandGrid(viewModel: AssistantViewModel) {
    val commands = listOf("ACTIVATE HUD", "SYSTEM STATUS", "SHOW BATTERY", "SHOW NETWORK")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        commands.forEach { label ->
            Surface(
                color = androidx.compose.ui.graphics.Color(0x55091A23),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.weight(1f).clickable {
                    viewModel.sendMessage(
                        when(label) {
                            "ACTIVATE HUD" -> "activate hud"
                            "SYSTEM STATUS" -> "show system status"
                            "SHOW BATTERY" -> "show battery"
                            else -> "show network"
                        }, true
                    )
                }
            ) {
                Text(label, color = JarvisCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(7.dp))
            }
        }
    }
}

@Composable
private fun HudChip(label: String, online: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).background(if (online) JarvisSuccess else JarvisError, CircleShape))
        Spacer(Modifier.width(5.dp))
        Text(label, color = JarvisTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

data class RadialMenuItem(val label: String, val onClick: () -> Unit)

/** #20 UI ARCHITECTURE — HUD-style radial quick-access menu, additive to the bottom nav bar
 * (not a replacement — see JARVIS_ULTRA_PASS_NOTES.md for why a full nav-shell replacement
 * wasn't attempted). Opened by long-pressing the Command Center core. Deliberately built with
 * only APIs already proven elsewhere in this file (Canvas/Modifier/graphicsLayer) rather than
 * androidx.compose.animation's AnimatedVisibility/fadeIn/scaleIn — that's a separate Gradle
 * artifact not explicitly declared in this project's dependencies, and pulling it in only
 * transitively is a real compile-time risk I can't verify without an actual build. */
@Composable
private fun RadialQuickMenu(visible: Boolean, onDismiss: () -> Unit, items: List<RadialMenuItem>) {
    if (!visible) return
    Box(
        modifier = Modifier.size(320.dp).clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        val radius = 130f
        val angleStep = 360f / items.size
        items.forEachIndexed { index, item ->
            val angle = Math.toRadians((angleStep * index - 90).toDouble())
            val x = (radius * kotlin.math.cos(angle)).dp
            val y = (radius * kotlin.math.sin(angle)).dp
            Surface(
                color = androidx.compose.ui.graphics.Color(0xEE06131C),
                shape = CircleShape,
                modifier = Modifier
                    .offset(x = x, y = y)
                    .size(52.dp)
                    .clickable { item.onClick(); onDismiss() }
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(item.label, color = JarvisCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

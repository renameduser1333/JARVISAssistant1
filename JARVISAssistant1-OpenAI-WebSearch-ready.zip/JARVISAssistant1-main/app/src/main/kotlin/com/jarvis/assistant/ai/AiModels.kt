package com.jarvis.assistant.ai

/** Simple conversation message used by JARVIS internally. */
data class ChatMessage(
    val role: String,
    val content: String
)

/** Provider-neutral result consumed by the rest of the app. */
data class AiResult(
    val replyText: String,
    val commandJson: String?
)

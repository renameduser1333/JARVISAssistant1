# JARVIS OpenAI Web Search build

This build uses the OpenAI Responses API (`/v1/responses`) with the hosted `web_search` tool.
No browser, Accessibility Service, or Brave Search API key is required for web search.

In JARVIS Settings:
- AI Base URL: leave blank for OpenAI
- AI Model: `gpt-5.6-luna` (or another Responses-compatible model with web search)
- AI API key: enter your own OpenAI API key on-device
- Brave Search API key: not required for this path
- Phone Control / Screen automation: unrelated to web search and may remain OFF
